package Funcionario;
public class ObjetoFuncionario {
    
    private String nome;
    private String tecnologia;

    void realizaProjeto(){     
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }   
}