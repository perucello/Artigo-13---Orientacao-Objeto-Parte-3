package Setor;

public class ObjetoSetor {
       private String funcao;


    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

}
